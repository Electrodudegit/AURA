# STEP

Put the AURA enclosure STEP file in this folder so subscribers can download it.

Nothing is here yet. ELECTRO DUDE adds the mechanical STEP when it is ready. Do not put credentials in the file or the filename.

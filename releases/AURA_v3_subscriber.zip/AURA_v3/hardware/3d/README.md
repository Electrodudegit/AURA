# 3D

Put STL, glTF, or rendered views of the AURA enclosure in this folder.

Nothing is here yet. ELECTRO DUDE adds these when they are ready. Do not put credentials in the files.

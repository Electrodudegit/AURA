# Hardware

Subscriber downloads for ELECTRO DUDE AURA. No passwords or API keys belong in these files.

| Folder | Contents |
|---|---|
| `schematic/` | Connection drawing, power path, and pin table. Already here. |
| `step/` | Enclosure STEP. ELECTRO DUDE will add it. |
| `3d/` | STL, glTF, or pictures. ELECTRO DUDE will add them. |

# Schematics

Electrical drawings for AURA / ELECTRO DUDE. No Wi-Fi passwords or API keys.

Already here:

- `AURA_connection_schematic.png` / `.svg` — wiring
- `AURA_pin_net_table.md` — pin net list
- `aura_power_path.png` / `.svg`, `aura_power_path.md`, `AURA_power_path_locked.md` — power path

Add further PDF or KiCad/EasyEDA exports in this folder.
